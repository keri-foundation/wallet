# -*- encoding: utf-8 -*-
"""
keri.kli.commands.oobi module

"""
import argparse

from hio.base import doing
from hio.help import ogler

from ...common import Parsery, setupHby, parseVersion

from ....app import HaberyDoer, Authenticator, Oobiery
from ....help import helping
from ....recording import OobiRecord

logger = ogler.getLogger()

parser = argparse.ArgumentParser(description="Resolve the provided OOBI", 
                                 parents=[Parsery.keystore()])
parser.set_defaults(handler=lambda args: resolve(args))
parser.add_argument("--oobi", "-o", help="out-of-band introduciton to load", required=True)
parser.add_argument("--oobi-alias", dest="oobiAlias", help="alias for AID resolved from out-of-band introduciton",
                    required=False, default=None)
parser.add_argument('--force', action="store_true", required=False,
                    help='True means to resolve OOBI even if it has already been previously resolved')
parser.add_argument('--version', default=None, required=False, type=parseVersion,
                    help='KERI protocol version for OOBI parsing, such as 1.0 or 2.0')


def resolve(args):
    """ command line method for resolving oobies

    Parameters:
        args(Namespace): parse args namespace object

    """
    name = args.name
    base = args.base
    bran = args.bran
    oobi = args.oobi
    oobiAlias = args.oobiAlias
    force = args.force
    version = args.version

    icpDoer = OobiDoer(name=name, oobi=oobi, bran=bran, base=base, oobiAlias=oobiAlias,
                       force=force, version=version)

    doers = [icpDoer]
    return doers


class OobiDoer(doing.DoDoer):
    """ DoDoer for loading oobis and waiting for the results """

    def __init__(self, name, oobi, oobiAlias, force=False, bran=None, base=None, version=None):

        self.processed = 0
        self.oobi = oobi
        self.force = force
        self.hby = setupHby(name=name, base=base, bran=bran, version=version)
        self.hbyDoer = HaberyDoer(habery=self.hby)

        obr = OobiRecord(date=helping.nowIso8601())
        if oobiAlias is not None:
            obr.oobialias = oobiAlias

        self.hby.db.oobis.put(keys=(oobi,), val=obr)

        self.obi = Oobiery(hby=self.hby, version=version)
        self.authn = Authenticator(hby=self.hby)
        doers = [self.hbyDoer, doing.doify(self.waitDo)]

        super(OobiDoer, self).__init__(doers=doers)

    def waitDo(self, tymth, tock=0.0, **kwa):
        """ Waits for oobis to load

        Parameters:
            tymth (function): injected function wrapper closure returned by .tymen() of
                Tymist instance. Calling tymth() returns associated Tymist .tyme.
            tock (float): injected initial tock value

        Returns:  doifiable Doist compatible generator method for loading oobis using
        the Oobiery
        """
        # enter context
        self.wind(tymth)
        self.tock = tock
        _ = (yield self.tock)

        if self.force:  # if --force specified, remove previous record of OOBI resolution
            self.hby.db.roobi.rem(keys=(self.oobi,))

        self.extend(self.obi.doers)
        self.extend(self.authn.doers)

        while not self.obi.hby.db.roobi.get(keys=(self.oobi,)):
            yield 0.25

        obr = self.obi.hby.db.roobi.get(keys=(self.oobi,))
        if self.force:
            while obr.cid not in self.hby.kevers:
                self.hby.kvy.processEscrows()
                yield 0.25

        print(self.oobi, obr.state)

        self.remove([self.hbyDoer, *self.obi.doers, *self.authn.doers])
